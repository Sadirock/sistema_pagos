<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_close_day extends Model
{
    protected $table = 'close_day';
    public $timestamps = false;
}
